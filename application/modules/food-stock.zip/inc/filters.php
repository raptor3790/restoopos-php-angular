<?php
class Food_Stock_Manager_Filters extends Tendoo_Module
{
    /**
     * Filter Admin Menus
     * @param array
     * @return array
    **/

    public function admin_menus( $menus )
    {
        $menus          =   array_insert_after( 'arrivages', $menus, 'stock-manager', [
            [
                'title'     =>  __( 'Food Stock', 'stock-manager' ),
                'href'      =>  site_url([ 'dashboard', store_slug(), 'food-stock' ]),
                'icon'      =>  'fa fa-exchange',
                'disable'   =>  true
            ],
            [
                'title'     =>  __( 'Food Stock List', 'stock-manager' ),
                'href'      =>  site_url([ 'dashboard', store_slug(), 'stock-transfert', 'history' ]),
            ],
            [
                'title'     =>  __( 'Add Food Stock', 'stock-manager' ),
                'href'      =>  site_url([ 'dashboard', store_slug(), 'stock-transfert', 'history', 'new' ]),
            ],
            [
                'title'     =>  __( 'Report', 'stock-manager' ),
                'href'      =>  site_url([ 'dashboard', store_slug(), 'stock-transfert', 'settings' ]),
            ]
        ]);
        return $menus;
    }
}